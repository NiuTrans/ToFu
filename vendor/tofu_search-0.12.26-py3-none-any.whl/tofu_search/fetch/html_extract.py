"""lib/fetch/html_extract.py — HTML content & metadata extraction.

Contains HTML text extraction (trafilatura + BS4 fallback), link extraction,
publication date extraction from meta tags / JSON-LD / <time> elements,
and specialized code-hosting blob extraction (GitHub / GitLab / Bitbucket).
"""

import json
import re
import threading
from datetime import timedelta
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import trafilatura
from trafilatura.deduplication import LRUCache
from trafilatura.settings import LRU_SIZE

from tofu_search.fetch.html_fragments import fragment_identifier, select_fragment_html
from tofu_search.fetch.html_rendering import javascript_notice, rendering_signals
from tofu_search.fetch.html_streaming import restore_completed_streams
from tofu_search.fetch.utils import _get_bs4
from tofu_search.log import get_logger

logger = get_logger(__name__)

# lxml 6.1.1 / libxml2 2.14.6 segfault when multiple threads enter
# `lxml.html.text_content()` simultaneously (observed via faulthandler:
# Current thread + 2+ other threads all inside text_content). trafilatura
# calls text_content() heavily inside delete_by_link_density() →
# prune_unwanted_sections() → extract(). With the search orchestrator
# running a 16-worker fetch pool and up to 5 concurrent batch queries
# (~80 concurrent extractions), the lxml thread-unsafety reliably crashes
# the server. We serialize extract() globally — cheap CPU work, ~tens of
# ms per page; the pool is dominated by network I/O so throughput is
# unaffected. The BS4 fallback uses Python's html.parser (GIL-safe) and
# does NOT need this lock.
_TRAFILATURA_LOCK = threading.Lock()

__all__ = [
    'extract_html_publish_date',
    'extract_links_from_soup',
    'extract_html_text',
]


class _PublicationTag:
    """Only the metadata interface used by date selection, without a DOM."""
    def __init__(self, name, attributes, string=None):
        self.name, self.attributes, self.string = name, attributes, string

    def get(self, name, default=None):
        return self.attributes.get(name, default)

    def __getitem__(self, name):
        return self.attributes[name]


class _PublicationMetadata(HTMLParser):
    """Retain meta, JSON-LD and time carriers from one bounded HTML prefix.

    The stdlib tokenizer is also BeautifulSoup's existing html.parser backend.
    No text/link tree, native parser, background worker or cross-request state
    is created. Selection/date validation remain in extract_html_publish_date.
    """
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.script = None
        self.script_parts = []

    def handle_starttag(self, tag, attrs):
        if tag not in ('meta', 'script', 'time'):
            return
        attributes = dict(attrs)
        if tag == 'meta':
            self.tags.append(_PublicationTag(tag, attributes))
        elif tag == 'time':
            if 'datetime' in attributes:
                self.tags.append(_PublicationTag(tag, attributes))
        elif attributes.get('type') == 'application/ld+json':
            self.script = _PublicationTag(tag, attributes)
            self.tags.append(self.script)
            self.script_parts = []

    def handle_data(self, data):
        if self.script is not None:
            self.script_parts.append(data)

    def handle_endtag(self, tag):
        if tag == 'script' and self.script is not None:
            self.script.string = ''.join(self.script_parts)
            self.script = None
            self.script_parts = []

    def close(self):
        super().close()
        if self.script is not None:
            # BeautifulSoup retains an unterminated script's text at EOF;
            # HTMLParser leaves that CDATA suffix buffered instead.
            self.script.string = ''.join(self.script_parts) + self.rawdata

    @staticmethod
    def _matches(tag, name, attrs):
        if tag.name != name:
            return False
        for key, expected in (attrs or {}).items():
            value = tag.get(key)
            if expected is True:
                if key not in tag.attributes:
                    return False
            elif isinstance(expected, re.Pattern):
                if not isinstance(value, str) or expected.search(value) is None:
                    return False
            elif value != expected:
                return False
        return True

    def find(self, name, attrs=None):
        return next((tag for tag in self.tags if self._matches(tag, name, attrs)), None)

    def find_all(self, name, attrs=None, **attributes):
        attributes = {**(attrs or {}), **attributes}
        return [tag for tag in self.tags if self._matches(tag, name, attributes)]


# ═══════════════════════════════════════════════════════
#  HTML 发布日期提取 (meta / JSON-LD / <time>)
# ═══════════════════════════════════════════════════════

def extract_html_publish_date(html):
    """Extract publication date from HTML meta tags, JSON-LD, or <time> elements.

    Checks (in priority order):
      1. <meta property="article:published_time">
      2. <meta name="pubdate|publishdate|publish_date|date|DC.date">
      3. JSON-LD "datePublished" / "dateCreated"
      4. <time datetime="..." pubdate> or first <time datetime>
    Returns ISO string 'YYYY-MM-DD' (day-level) or '' if not found.
    """
    if not html:
        return ''

    from dateutil import parser as dateutil_parser

    def _try_parse(raw):
        """Try to parse a date string into a day-level 'YYYY-MM-DD' format."""
        if not raw or not isinstance(raw, str):
            return ''
        raw = raw.strip()
        if not raw:
            return ''
        try:
            dt = dateutil_parser.parse(raw, fuzzy=True)
            # Normalize to naive (strip timezone for comparison)
            if dt.tzinfo is not None:
                from datetime import timezone
                dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
            # Sanity check: reject dates in the far future or before 2000
            from datetime import datetime as _dt
            if dt.year < 2000 or dt > _dt.now() + timedelta(days=2):
                return ''
            return dt.strftime('%Y-%m-%d')
        except (ValueError, OverflowError):
            logger.debug('[Fetch] Date parse failed for raw=%r', raw, exc_info=True)
            return ''

    try:
        if type(html) is str:
            soup = _PublicationMetadata()
            soup.feed(html[:50000])
            soup.close()
        else:
            # Preserve BeautifulSoup's decoding/custom-carrier behavior.
            soup = _get_bs4()(html[:50000], 'html.parser')
    except Exception as e:
        logger.debug('[Fetch] BS4 parse failed for publish date extraction: %s', e, exc_info=True)
        return ''

    # ── 1. <meta> OG / standard meta tags ──
    meta_props = [
        'article:published_time', 'article:published',
        'og:article:published_time', 'og:published_time',
    ]
    for prop in meta_props:
        tag = soup.find('meta', attrs={'property': prop})
        if tag and tag.get('content'):
            r = _try_parse(tag['content'])
            if r:
                return r

    meta_names = [
        'pubdate', 'publishdate', 'publish_date', 'date',
        'DC.date', 'DC.date.issued', 'sailthru.date',
        'article.published', 'published_time', 'creation_date',
    ]
    for name in meta_names:
        tag = soup.find('meta', attrs={'name': re.compile(f'^{re.escape(name)}$', re.I)})
        if tag and tag.get('content'):
            r = _try_parse(tag['content'])
            if r:
                return r

    # ── 2. JSON-LD (schema.org) ──
    for script in soup.find_all('script', type='application/ld+json'):
        try:
            raw_ld = (script.string or '').strip()
            if not raw_ld:
                continue
            ld = json.loads(raw_ld)
            items = ld if isinstance(ld, list) else [ld]
            for item in items:
                if not isinstance(item, dict):
                    continue
                for key in ('datePublished', 'dateCreated', 'uploadDate'):
                    val = item.get(key)
                    if val:
                        r = _try_parse(val)
                        if r:
                            return r
                # Check nested @graph
                for g in (item.get('@graph') or []):
                    if isinstance(g, dict):
                        for key in ('datePublished', 'dateCreated'):
                            val = g.get(key)
                            if val:
                                r = _try_parse(val)
                                if r:
                                    return r
        except (json.JSONDecodeError, TypeError, AttributeError):
            logger.debug('[Fetch] JSON-LD parse error in publish date extraction', exc_info=True)
            continue

    # ── 3. <time> elements ──
    for time_tag in soup.find_all('time', attrs={'datetime': True}):
        r = _try_parse(time_tag['datetime'])
        if r:
            return r

    return ''


# ═══════════════════════════════════════════════════════
#  Link extraction
# ═══════════════════════════════════════════════════════

def extract_links_from_soup(soup, base_url=''):
    """Extract meaningful links from a parsed soup element, returning a markdown-style link section."""
    links = []
    seen_urls = set()
    for a in soup.find_all('a', href=True):
        href = a['href'].strip()
        if not href or href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
            continue
        # Resolve relative URLs
        if base_url and not href.startswith(('http://', 'https://')):
            href = urljoin(base_url, href)
        if href in seen_urls:
            continue
        seen_urls.add(href)
        text = a.get_text(strip=True)
        if not text or len(text) < 2:
            continue
        # Skip trivial navigation links
        if text.lower() in ('home', 'back', 'top', 'skip', '↑', '←', '→', '↓', '#'):
            continue
        links.append(f'- [{text}]({href})')
    return links


# ═══════════════════════════════════════════════════════
#  Code-hosting blob extraction (GitHub / GitLab / Bitbucket)
# ═══════════════════════════════════════════════════════

# Regex: GitHub blob URLs  /owner/repo/blob/ref/path.ext
_GITHUB_BLOB_URL_RE = re.compile(
    r'^https?://github\.com/[^/]+/[^/]+/blob/.+\.[a-zA-Z0-9]+$'
)

# GitHub embeds source code as JSON inside a <script type="application/json"
# data-target="react-app.embeddedData"> block, with a "rawLines" array.
_GITHUB_EMBEDDED_RE = re.compile(
    r'<script\s+type="application/json"\s+'
    r'data-target="react-app\.embeddedData"[^>]*>(.*?)</script>',
    re.DOTALL,
)


def _find_nested_key(obj, key, depth=0):
    """Recursively search a JSON object for a key, returning its value."""
    if depth > 12:
        return None
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for v in obj.values():
            r = _find_nested_key(v, key, depth + 1)
            if r is not None:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = _find_nested_key(v, key, depth + 1)
            if r is not None:
                return r
    return None


def _try_extract_github_blob(html_text, url):
    """Extract source code from a GitHub blob page's embedded JSON payload.

    GitHub renders code files via React (JavaScript), so a plain HTTP GET
    on a /blob/ URL returns an HTML shell with no visible source code.
    However, the raw code is embedded as a JSON array ``rawLines`` inside a
    ``<script type="application/json" data-target="react-app.embeddedData">``
    block.  This function extracts those lines directly from the HTML,
    avoiding the need for URL rewriting or JavaScript rendering.

    Returns:
        Formatted source code string, or None if extraction fails.
    """
    m = _GITHUB_EMBEDDED_RE.search(html_text)
    if not m:
        return None
    try:
        payload = json.loads(m.group(1))
    except (json.JSONDecodeError, TypeError) as e:
        logger.debug('[Fetch] GitHub embeddedData JSON parse failed: %s', e)
        return None

    raw_lines = _find_nested_key(payload, 'rawLines')
    if not raw_lines or not isinstance(raw_lines, list):
        logger.debug('[Fetch] GitHub blob matched but no rawLines — %s', url[:80])
        return None

    code = '\n'.join(raw_lines)
    if len(code) < 10:
        logger.debug('[Fetch] GitHub blob rawLines too short (%d chars) — %s', len(code), url[:80])
        return None

    # Extract metadata for a nice header
    file_path = _find_nested_key(payload, 'path') or ''
    language = _find_nested_key(payload, 'language') or ''

    # Build formatted output
    parts = []
    if file_path:
        header = f'File: {file_path}'
        if language:
            header += f'  ({language})'
        header += f'  — {len(raw_lines)} lines'
        parts.append(header)
        parts.append('')
    parts.append(code)

    logger.debug('[Fetch] GitHub blob extracted: %s — %d lines, %d chars',
                 file_path or url[:80], len(raw_lines), len(code))
    return '\n'.join(parts)


def _try_extract_code_blob(html_text, url):
    """Try to extract source code from a code-hosting page (GitHub, GitLab, Bitbucket).

    Dispatches to platform-specific extractors based on the URL.
    Returns the extracted source code string, or None if not a code page
    or extraction failed (caller should fall through to normal extraction).
    """
    if not url:
        return None
    try:
        host = urlparse(url).netloc.lower()
    except Exception as e:
        logger.debug('[HTMLExtract] URL parse failed for %.80s: %s', url, e)
        return None

    # ── GitHub blob pages ──
    if host == 'github.com' and _GITHUB_BLOB_URL_RE.match(url):
        return _try_extract_github_blob(html_text, url)

    # GitLab and Bitbucket use full JS rendering (no embedded code in HTML),
    # so they fall through to the URL-rewrite approach in _normalize_code_hosting_url().
    return None


# ═══════════════════════════════════════════════════════
#  HTML text extraction
# ═══════════════════════════════════════════════════════

_INLINE_VALUE_TAGS = frozenset({
    'a', 'abbr', 'b', 'bdi', 'bdo', 'br', 'cite', 'code', 'data', 'del', 'dfn',
    'em', 'i', 'img', 'ins', 'kbd', 'mark', 'q', 'ruby', 's', 'samp', 'small',
    'span', 'strong', 'sub', 'sup', 'time', 'u', 'var', 'wbr',
})
_PROTECTED_VALUE_ANCESTORS = frozenset({
    'nav', 'header', 'footer', 'aside', 'form', 'svg', 'math', 'pre', 'code', 'table',
})
_DISPLAY_NONE = re.compile(r'display\s*:\s*none', re.I)


def _explicitly_hidden(element):
    """Shared visibility boundary for the article tree and BS4 fallback."""
    return (
        element.get('hidden') is not None
        or str(element.get('aria-hidden', '')).strip().lower() == 'true'
        or bool(_DISPLAY_NONE.search(str(element.get('style', ''))))
    )


def _prepare_article_tree(html):
    """Represent adjacent div values as paragraphs for the upstream extractor.

    Only change extraction markup; keep text, attributes, siblings and inline
    structure intact. Do not infer CSS grid columns, labels or relationships.
    Native tree work must remain inside _TRAFILATURA_LOCK.
    """
    tree = trafilatura.load_html(html)
    if tree is None:
        return None
    for element in list(tree.iter()):
        if _explicitly_hidden(element):
            if element is tree:
                return None
            # Unlike parent.remove(), drop_tree keeps the visible following tail.
            element.drop_tree()

    def value_cell(element):
        return element.tag == 'div' and all(
            not isinstance(child.tag, str) or child.tag in _INLINE_VALUE_TAGS
            for child in element.iterdescendants())

    def preserve_run(parent, cells):
        # A run of linked cards is navigation, not a field group. Preserve
        # the upstream link-density decision unless at least two cells
        # carry their own non-link words (inline linked values still fit).
        def has_unlinked_words(cell):
            return any(re.search(r'\w', text) for text in
                       cell.xpath('.//text()[not(ancestor::a)]'))

        if sum(has_unlinked_words(cell) for cell in cells) < 2:
            return
        paragraph = parent.makeelement('p')
        position = parent.index(cells[0])
        for index, cell in enumerate(cells):
            cell.tag = 'span'
            parent.remove(cell)
            paragraph.append(cell)
            if index + 1 < len(cells):
                paragraph.append(parent.makeelement('br'))
        parent.insert(position, paragraph)

    # Process inner groups first. A parent containing paragraphs then remains
    # a structural container; its prose is never folded into the value group.
    for parent in reversed(list(tree.iter())):
        if parent.tag not in {'div', 'section', 'main', 'article'}:
            continue
        if any(ancestor.tag in _PROTECTED_VALUE_ANCESTORS for ancestor in parent.iterancestors()):
            continue
        run = []

        for child in list(parent):
            if value_cell(child):
                run.append(child)
            else:
                preserve_run(parent, run)
                run = []
        preserve_run(parent, run)
    return tree


_NOISE_CLASS_NAME = re.compile(r'\b(cookie|popup|modal|banner|advert|sidebar|menu|nav)\b', re.I)
# A bracketed part of a class token is a CSS value or selector (Tailwind
# arbitrary values such as pt-[calc(10rem+var(--banner-height))]), not a
# component name; matching it removed whole content wrappers.
_CLASS_CSS_VALUE = re.compile(r'\[[^\]]*\]')


def _noise_class(value):
    return bool(value) and bool(_NOISE_CLASS_NAME.search(_CLASS_CSS_VALUE.sub('', value)))


def _sanitized_soup(html, *, rendering=None):
    """Use one visibility/navigation boundary for scopes and full documents."""
    soup = _get_bs4()(html, 'html.parser')
    requires_javascript = javascript_notice(soup) if rendering is not None else False
    for tag in ['script', 'style', 'nav', 'header', 'footer', 'aside', 'iframe',
                'noscript', 'form', 'svg', 'input', 'select', 'textarea']:
        for element in soup.find_all(tag):
            element.decompose()
    for element in soup.find_all(_explicitly_hidden):
        element.decompose()
    for element in soup.find_all(class_=_noise_class):
        element.decompose()
    if rendering is not None:
        rendering.update(rendering_signals(soup, requires_javascript=requires_javascript))
    return soup


def extract_html_text(html, max_chars, url='', *, scope=None):
    """Extract readable source, focusing a recognized URL fragment when possible.

    Optional ``scope`` records the matched ``fragment`` and sanitized whole-page
    ``document_text`` for SPA detection only after successful extraction.
    Unknown, ambiguous, hidden or unreadable targets keep the whole document.
    Code-hosting extraction retains its existing owner and priority.
    """
    if scope is not None:
        scope.pop('fragment', None)
        scope.pop('document_text', None)
        scope.pop('rendering', None)

    # ── Phase 0: Code-hosting blob extraction (GitHub embeds code in JSON) ──
    code = _try_extract_code_blob(html, url)
    if code:
        if max_chars and len(code) > max_chars:
            code = code[:max_chars] + '\n[…truncated]'
        return code

    # Completed server-rendered HTML can arrive in a hidden transport segment.
    # Restore its declared position before the shared visibility/fragment rules.
    try:
        html = restore_completed_streams(html)
    except Exception:
        logger.debug('Unrecognized HTML stream kept unchanged', exc_info=True)

    fragment = fragment_identifier(url)
    if fragment:
        try:
            rendering = scope.setdefault('rendering', {}) if scope is not None else None
            soup = _sanitized_soup(html, rendering=rendering)
            selected = select_fragment_html(soup, fragment)
            if selected:
                text = _extract_html_document(selected, max_chars, url)
                if text:
                    if scope is not None:
                        scope['fragment'] = fragment
                        # A short section is not proof of an empty page, and a
                        # matching loading stub is not proof of a readable one.
                        scope['document_text'] = soup.get_text(' ', strip=True)
                    return text
        except Exception:
            logger.debug('HTML fragment extraction could not retain its scope', exc_info=True)
    return _extract_html_document(html, max_chars, url, scope=scope)


def _extract_html_document(html, max_chars, url, *, scope=None):
    """Extract one already-selected document through the common fidelity path."""
    # ── Phase 1: Try trafilatura for main text extraction ──
    # Serialized via _TRAFILATURA_LOCK — see module-level note on lxml
    # text_content() thread-unsafety crashing the server.
    main_text = None
    try:
        with _TRAFILATURA_LOCK:
            # True selects upstream's process-global cache even in 2.3.1.
            # Keep its existing capacity, but scope every entry to this document.
            main_text = trafilatura.extract(_prepare_article_tree(html),
                                            include_comments=False, include_tables=True,
                                            no_fallback=False, favor_recall=True,
                                            deduplicate=LRUCache(maxsize=LRU_SIZE),
                                            include_links=True,        # ★ include_links!
                                            include_formatting=True)   # ★ keep headings/lists/emphasis as markdown
    except Exception as e:
        logger.warning('Trafilatura failed for %s: %s', url[:80], e, exc_info=True)

    # ── Phase 2: BeautifulSoup fallback / link extraction ──
    try:
        rendering = scope.setdefault('rendering', {}) if scope is not None else None
        soup = _sanitized_soup(html, rendering=rendering)
        # ★ Priority: <main> before <article> — <article> can be a single card/widget
        #   while <main> wraps the full page content (e.g. HuggingFace collections)
        main_el = None
        for c in [soup.find('main'), soup.find(role='main'),
                   soup.find(id=re.compile(r'^(content|main|article)', re.I)),
                   soup.find(class_=re.compile(r'^(post|article|content|main)', re.I)),
                   soup.find('article')]:
            if c and len(c.get_text(strip=True)) > 50: main_el = c; break

        content_el = main_el or soup.body or soup

        # ── Extract links: prioritize content area, then rest of body ──
        body_el = soup.body or soup
        content_links = extract_links_from_soup(content_el, base_url=url)
        content_urls = {l.split('](')[-1].rstrip(')') for l in content_links if '](' in l}
        # Get body links that aren't already in content_links
        body_links = extract_links_from_soup(body_el, base_url=url)
        extra_links = [l for l in body_links
                       if l.split('](')[-1].rstrip(')') not in content_urls]
        links = content_links + extra_links

        if not main_text:
            # Trafilatura failed, use BS fallback
            text = content_el.get_text(separator='\n', strip=True)
            lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
            main_text = re.sub(r'\n{3,}', '\n\n', '\n'.join(lines))
            if not main_text or len(main_text) < 30:
                return None
    except Exception as e:
        logger.warning('BS4 extraction failed for %s: %s', url[:80], e, exc_info=True)
        if main_text:
            links = []
        else:
            return None

    # Tables carry row/column relationships that article heuristics can omit.
    # Supplement from the existing content DOM, never a second fetch or model.
    if main_text and 'content_el' in locals():
        supplemental = []
        known = re.sub(r'\s+', ' ', main_text)
        for table in content_el.find_all('table'):
            rows = []
            for row in table.find_all('tr'):
                cells = [re.sub(r'\s+', ' ', cell.get_text(' ', strip=True)).replace('|', '\\|')
                         for cell in row.find_all(['th', 'td'], recursive=False)]
                if cells:
                    rows.append('| ' + ' | '.join(cells) + ' |')
            rendered = '\n'.join(rows)
            if rendered and re.sub(r'\s+', ' ', rendered) not in known:
                supplemental.append(rendered)
        # Article heuristics can flatten highlighted/list-nested code or remove
        # blank lines. Whitespace is source evidence here, not dedup noise.
        # Recover original DOM text using the same sanitized content boundary.
        preserved_code = set()
        for element in content_el.find_all('pre'):
            value = element.get_text().replace('\r\n', '\n').replace('\r', '\n').strip('\n')
            if value.strip() and value not in main_text and value not in preserved_code:
                fence = '`' * max(3, max((len(run) + 1 for run in re.findall(r'`+', value)),
                                        default=0))
                supplemental.append(f'{fence}\n{value}\n{fence}')
                preserved_code.add(value)
        # Documentation UIs often put exact identifiers inside copy buttons.
        for element in content_el.find_all('button'):
            value = element.get_text(' ', strip=True)
            if value and re.sub(r'\s+', ' ', value) not in known:
                supplemental.append(value)
        if supplemental:
            main_text += '\n\n--- Additional source structures ---\n' + '\n\n'.join(supplemental)

    # ── Phase 3: Append link section (if we have links and main text) ──
    if links and main_text:
        # Relevance scoring: rank links by how related they are to the main text
        text_lower = main_text[:5000].lower() if main_text else ''
        if text_lower:
            def _link_score(link_md):
                score = 0
                # Extract URL and text from "- [text](url)"
                parts = link_md.split('](')
                if len(parts) != 2:
                    return 0
                text_part = parts[0].lstrip('- [')
                url_part = parts[1].rstrip(')')
                # Score based on URL path keywords appearing in main text
                path = url_part.split('/')[-1].replace('-', ' ').replace('_', ' ').lower()
                for word in path.split():
                    if len(word) > 3 and word in text_lower:
                        score += 3
                # Link text that appears in main_text
                for word in text_part.lower().split():
                    if len(word) > 3 and word in text_lower:
                        score += 1
                return score
            scored = [(l, _link_score(l)) for l in links]
            scored.sort(key=lambda x: -x[1])
            selected = [l for l, s in scored[:80]]
        else:
            selected = links[:80]
        link_section = '\n\n--- Page Links ---\n' + '\n'.join(selected)
        combined = main_text + link_section
    else:
        combined = main_text

    if max_chars and len(combined) > max_chars:
        combined = combined[:max_chars] + '\n[…truncated]'
    return combined


# Backward-compatible aliases (these were originally _-prefixed private names)
_extract_links_from_soup = extract_links_from_soup
_extract_html_text = extract_html_text
